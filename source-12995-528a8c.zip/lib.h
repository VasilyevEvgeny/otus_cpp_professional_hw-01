#pragma once

int version();
